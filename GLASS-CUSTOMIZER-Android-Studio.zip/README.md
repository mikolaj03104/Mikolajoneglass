# GLASS CUSTOMIZER

Natywny projekt Android Studio (Kotlin + Jetpack Compose) przygotowany z myślą o telefonach Samsung, w tym Galaxy A55 5G. Aplikacja działa lokalnie i nie potrzebuje konta, API ani backendu.

## Co działa w tej wersji

- Ekran główny i nawigacja Compose w języku polskim.
- 10 gotowych palet Liquid Glass.
- Kreator tapety z wyborem palety i importem zdjęcia przez Android Photo Picker.
- Eksport tapety PNG do `Zdjęcia/Pictures/GlassCustomizer`.
- Ustawianie obrazu jako tapety ekranu głównego, blokady lub obu przez publiczny `WallpaperManager`.
- Lokalny zapis wygenerowanego PNG projektu, duplikowanie i usuwanie.
- Studio podglądów dla szkła, ikon, Quick Panelu, ekranu blokady i tła klawiatury; eksportuje lokalną grafikę PNG.
- Hub opisujący realne możliwości Androida, One UI, Theme Park i launcherów.
- Natywny widget zegara i dekoracyjnego podpisu; użytkownik dodaje go z systemowej listy widgetów.
- Aplikacja nie zbiera danych i nie wysyła obrazów poza urządzenie.

## Ograniczenia, które aplikacja pokazuje w interfejsie

- Publiczne API Androida nie pozwala tej aplikacji podmienić systemowego Quick Panelu, zegara One UI, ikon wszystkich aplikacji ani wyglądu powiadomień.
- PNG ikon jest materiałem do ręcznego użycia. Obsługa paczki ikon i mapowanie aplikacji zależą od launchera; ta wersja nie publikuje pakietu ikon Androida.
- Ekran Studio generuje podglądowe grafiki dekoracyjne. Zaawansowane warstwy z niezależnym przesuwaniem, skalowaniem i obrotem nie są jeszcze pełnym edytorem.
- Zapis projektu przechowuje render PNG, a nie edytowalną listę warstw.
- Możliwość ustawienia tapety ekranu blokady zależy od wersji Androida i implementacji producenta. Błąd urządzenia jest pokazany jako komunikat, bez udawania powodzenia.
- Widget jest prostym widgetem Android App Widget z zegarem systemowym; pozostałe typy (cytat, licznik dni i panel informacyjny) nie są w tej wersji wdrożone.

## Budowanie APK przez GitHub Actions — także z telefonu

Repozytorium zawiera workflow `.github/workflows/build-apk.yml`. Możesz przesłać do repozytorium sam plik projektu ZIP, a workflow rozpakowuje go i buduje APK. Nie są potrzebne sekrety ani klucze API.

1. Pobierz `GLASS-CUSTOMIZER-Android-Studio.zip` na telefon.
2. W przeglądarce otwórz GitHub i utwórz nowe, najlepiej prywatne repozytorium. Zaznacz utworzenie README, żeby od razu powstała gałąź główna.
3. W repozytorium wybierz **Add file → Create new file**. Jako ścieżkę wpisz dokładnie `.github/workflows/build-apk.yml`.
4. Otwórz w pobranym archiwum plik `GITHUB-ACTIONS-WORKFLOW.txt`, skopiuj jego całą treść, wklej ją do edytora GitHuba i zatwierdź **Commit changes** do `main`.
5. Wybierz **Add file → Upload files**, wskaż pobrane `GLASS-CUSTOMIZER-Android-Studio.zip` i zatwierdź commit do `main`.
6. Otwórz kartę **Actions**, wybierz **Build GLASS CUSTOMIZER APK**, kliknij **Run workflow** i zatwierdź uruchomienie.
7. Po zakończeniu zielonego zadania otwórz jego stronę i w sekcji **Artifacts** pobierz `glass-customizer-debug-apk`. Rozpakuj pobrane archiwum na telefonie — w środku będzie `app-debug.apk`.
8. Otwórz APK. Jeśli Android zapyta, zezwól jednorazowo na instalowanie aplikacji z przeglądarki lub menedżera plików.

Workflow buduje debug APK na GitHub-hosted runnerze. GitHub zachowuje artefakt przez 14 dni. Pierwsze uruchomienie pobiera Gradle i zależności projektu. Jeśli tworzysz repozytorium bez użycia ZIP, skopiuj do niego cały projekt wraz z katalogiem `.github/workflows`.

## Budowanie APK w Android Studio

1. Zainstaluj Android Studio oraz JDK 17.
2. Otwórz folder projektu `GLASS_CUSTOMIZER` w Android Studio.
3. Zainstaluj Android SDK Platform 35 (lub nowszą obsługiwaną przez skonfigurowany Android Gradle Plugin) w SDK Managerze.
4. Poczekaj na synchronizację Gradle. Pierwsze budowanie pobiera Android Gradle Plugin i biblioteki; gotowa aplikacja działa offline.
5. Wybierz **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug znajdziesz w `app/build/outputs/apk/debug/app-debug.apk`.

Alternatywnie w terminalu z Gradle Wrapperem i Android SDK:

```bash
./gradlew assembleDebug
```

## Instalacja na Galaxy A55 5G

Przenieś `app-debug.apk` na telefon i otwórz go. Android może poprosić o jednorazowe zezwolenie na instalowanie aplikacji z używanej przeglądarki lub menedżera plików. To instalacja lokalna, poza Google Play.

## Raport weryfikacji tego środowiska

- Przejrzano wygenerowane pliki projektu i manifest.
- Środowisko nie ma zainstalowanego Android SDK, więc kompilacja APK i uruchomienie emulatora nie były dostępne. APK nie jest deklarowany jako zbudowany.
- Dołączony Wrapper 8.11.1 uruchomił się na JDK 17; archiwum ZIP przeszło test integralności, a workflow YAML został sparsowany.
- Projekt używa Android Gradle Plugin 8.9.2, Kotlin 2.0.21, JDK 17 i Compose BOM 2025.02.00.

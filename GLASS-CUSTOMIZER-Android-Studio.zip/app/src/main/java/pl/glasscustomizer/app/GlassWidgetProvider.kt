package pl.glasscustomizer.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

/** Minimalzny, natywny widget systemowy. TextClock aktualizuje godzinę bez cyklicznego budzenia aplikacji. */
class GlassWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> manager.updateAppWidget(id, RemoteViews(context.packageName, R.layout.glass_widget)) }
    }
}

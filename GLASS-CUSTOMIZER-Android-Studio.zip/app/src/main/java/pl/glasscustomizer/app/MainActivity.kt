package pl.glasscustomizer.app

import android.app.WallpaperManager
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas as NativeCanvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF080A12)
private val Panel = Color(0xFF151A29)
private val Ice = Color(0xFF9DEBFF)
private val White = Color(0xFFF2F7FF)
private val Muted = Color(0xFF9AA8BB)
private val AccentSet = listOf(0xFF9DEBFF, 0xFFBFA6FF, 0xFFFF667F, 0xFF8DE3C2, 0xFFFFCE8A, 0xFF82A9FF)

private data class ThemePreset(val name: String, val tag: String, val colors: List<Color>, val glyph: String)
private val presets = listOf(
    ThemePreset("Crystal Clear", "PRZEJRZYSTY", listOf(Color(0xFF80D7FF), Color(0xFF293E63), Color(0xFF080E1B)), "◇"),
    ThemePreset("Obsidian", "DARK LUXURY", listOf(Color(0xFF7C8AA4), Color(0xFF303744), Color(0xFF090B10)), "◈"),
    ThemePreset("Arctic Glass", "ICE BLUE", listOf(Color(0xFFB3F5FF), Color(0xFF387B9E), Color(0xFF101E34)), "❄"),
    ThemePreset("Cherry Glass", "WIŚNIOWY BLASK", listOf(Color(0xFFFF829B), Color(0xFF8A244E), Color(0xFF210D22)), "✿"),
    ThemePreset("Silver Liquid", "CHROM", listOf(Color(0xFFD8E2F2), Color(0xFF68778D), Color(0xFF151923)), "◌"),
    ThemePreset("Cosmic Purple", "KOSMOS", listOf(Color(0xFFD2A1FF), Color(0xFF663CC2), Color(0xFF100B27)), "✧"),
    ThemePreset("Neon Red", "NEON", listOf(Color(0xFFFF445D), Color(0xFF902131), Color(0xFF190B13)), "✦"),
    ThemePreset("Midnight Blue", "NOC", listOf(Color(0xFF76A7FF), Color(0xFF243A76), Color(0xFF080D21)), "☾"),
    ThemePreset("Dark Chrome", "CHŁODNY METAL", listOf(Color(0xFFC2D0DE), Color(0xFF485361), Color(0xFF101318)), "▱"),
    ThemePreset("Aurora", "ZORZA", listOf(Color(0xFF6BF0D2), Color(0xFF735CE0), Color(0xFF11132B)), "✺")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 10, 18)
        window.navigationBarColor = android.graphics.Color.rgb(8, 10, 18)
        setContent { GlassApp(this) }
    }
}

@Composable
private fun GlassApp(activity: ComponentActivity) {
    var page by remember { mutableStateOf("Start") }
    var preset by remember { mutableStateOf(presets[0]) }
    var selectedColor by remember { mutableIntStateOf(0) }
    var imported by remember { mutableStateOf<Bitmap?>(null) }
    var blur by remember { mutableFloatStateOf(0.12f) }
    var glass by remember { mutableFloatStateOf(0.45f) }
    var projectRefresh by remember { mutableIntStateOf(0) }
    var selectedDesign by remember { mutableStateOf("Szkło") }
    var notice by remember { mutableStateOf<String?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) runCatching { decodePhoto(activity, uri) }.onSuccess { imported = it }
    }
    LaunchedEffect(notice) { notice?.let { snackbar.showSnackbar(it); notice = null } }
    MaterialTheme(colorScheme = darkColorScheme(primary = Ice, background = Ink, surface = Panel, onBackground = White, onSurface = White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10182A), Ink, Color(0xFF0C101C))))) {
            Column(Modifier.fillMaxSize()) {
                Header()
                AnimatedContent(page, label = "page", modifier = Modifier.weight(1f)) { active ->
                    when (active) {
                        "Start" -> HomePage(preset, { page = it }, { pickImage.launch("image/*") }, { page = "Motywy" })
        "Tapety" -> WallpaperPage(activity, preset, imported, selectedColor, blur, glass,
                            { selectedColor = it }, { blur = it }, { glass = it }, { pickImage.launch("image/*") }, { notice = it }, { projectRefresh++ })
                        "Studio" -> StudioPage(activity, preset, selectedDesign, { selectedDesign = it }, { pickImage.launch("image/*") }, { notice = it })
                        "Samsung" -> SamsungPage(activity)
                        "Motywy" -> PresetsPage(preset, { preset = it; selectedColor = presets.indexOf(it).mod(AccentSet.size); page = "Start" })
                        "Projekty" -> ProjectsPage(activity, projectRefresh, { notice = it })
                        else -> HomePage(preset, { page = it }, { pickImage.launch("image/*") }, { page = "Motywy" })
                    }
                }
                NavigationBar(containerColor = Color(0xEE0B0E17), contentColor = Muted, tonalElevation = 0.dp) {
                    listOf("Start" to Icons.Rounded.SpaceDashboard, "Tapety" to Icons.Rounded.Wallpaper, "Studio" to Icons.Rounded.AutoAwesome, "Samsung" to Icons.Rounded.Tune, "Projekty" to Icons.Rounded.FolderOpen).forEach { (name, icon) ->
                        NavigationBarItem(selected = page == name, onClick = { page = name }, icon = { Icon(icon, null) }, label = { Text(name, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Ice, selectedTextColor = Ice, indicatorColor = Color(0x3328CFFF), unselectedIconColor = Muted, unselectedTextColor = Muted))
                    }
                }
            }
            SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(bottom = 78.dp))
        }
    }
}

@Composable private fun Header() {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Ice.copy(.8f), Color(0xFF6554D9)))), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.AutoAwesome, null, tint = Ink) }
        Column(Modifier.padding(start = 11.dp).weight(1f)) {
            Text("GLASS CUSTOMIZER", fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = 1.7.sp, color = White)
            Text("TWOJA PRZESTRZEŃ. TWÓJ STYL.", fontSize = 8.sp, letterSpacing = 1.1.sp, color = Muted)
        }
        Box(Modifier.clip(CircleShape).background(Color(0x2229D1FF)).border(1.dp, Ice.copy(.22f), CircleShape).padding(horizontal = 10.dp, vertical = 6.dp)) { Text("OFFLINE", fontSize = 9.sp, color = Ice, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun Screen(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp).verticalScroll(rememberScrollState()), content = content)
}

@Composable private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().shadow(12.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp))
        .background(Brush.linearGradient(listOf(Color(0xCC293649), Color(0xAA171D2B), Color(0xCC101522))))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.28f), Ice.copy(.1f), Color.White.copy(.04f))), RoundedCornerShape(24.dp))
        .padding(16.dp), content = content)
}

@Composable private fun Title(text: String, subtitle: String? = null) {
    Text(text, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = White)
    if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = Muted, lineHeight = 18.sp, modifier = Modifier.padding(top = 4.dp, bottom = 15.dp))
}

@Composable private fun HomePage(preset: ThemePreset, navigate: (String) -> Unit, pick: () -> Unit, motifs: () -> Unit) = Screen {
    Spacer(Modifier.height(4.dp))
    Text("DOBRY WIECZÓR", fontSize = 10.sp, color = Ice, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
    Title("Zrób to po swojemu.", "Twórz tapety i szklane dodatki. Zmiany systemowe wykonujesz świadomie w narzędziach Samsunga.")
    GlassCard(Modifier.padding(bottom = 15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("TWÓJ AKTUALNY MOTYW", color = Muted, fontSize = 9.sp, letterSpacing = 1.2.sp)
                Text(preset.name, color = White, fontWeight = FontWeight.Bold, fontSize = 21.sp, modifier = Modifier.padding(top = 7.dp))
                Text(preset.tag, color = Ice, fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp))
                Spacer(Modifier.height(14.dp)); ActionButton("Przeglądaj motywy", motifs, icon = Icons.Rounded.Palette)
            }
            ThemeOrb(preset.colors, preset.glyph, Modifier.size(112.dp))
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 14.dp)) {
        QuickTile("Kreator tapet", "PNG • tapeta systemowa", Icons.Rounded.Wallpaper, Modifier.weight(1f)) { navigate("Tapety") }
        QuickTile("Glass studio", "Ikony • panel • klawiatura", Icons.Rounded.AutoAwesome, Modifier.weight(1f)) { navigate("Studio") }
    }
    GlassCard(Modifier.padding(bottom = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.PhoneAndroid, null, tint = Ice)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text("Galaxy A55 5G", color = White, fontWeight = FontWeight.SemiBold); Text("Centrum możliwości i ograniczeń One UI", color = Muted, fontSize = 10.sp) }
            IconButton(onClick = { navigate("Samsung") }) { Icon(Icons.Rounded.ArrowForward, null, tint = Ice) }
        }
    }
    SectionLabel("SZYBKI START")
    listOf("Wybierz zdjęcie z galerii" to Icons.Rounded.AddPhotoAlternate, "Zrób nową tapetę" to Icons.Rounded.Brush, "Dodaj zegar na ekran główny" to Icons.Rounded.Widgets).forEachIndexed { i, (label, icon) ->
        Row(Modifier.fillMaxWidth().clickable { if (i == 0) pick() else navigate(if (i == 1) "Tapety" else "Samsung") }.padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Ice, modifier = Modifier.size(20.dp)); Text(label, Modifier.weight(1f).padding(start = 12.dp), color = White, fontSize = 13.sp); Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
        }
    }
    Spacer(Modifier.height(10.dp))
}

@Composable private fun QuickTile(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, action: () -> Unit) {
    GlassCard(modifier.clickable { action() }) { Icon(icon, null, tint = Ice); Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 15.dp)); Text(sub, color = Muted, fontSize = 9.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 4.dp)) }
}

@Composable private fun SectionLabel(text: String) { Text(text, color = Muted, fontSize = 9.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp, bottom = 7.dp)) }

@Composable private fun ThemeOrb(colors: List<Color>, glyph: String, modifier: Modifier = Modifier) {
    Box(modifier.clip(CircleShape).background(Brush.linearGradient(colors)).border(1.dp, Color.White.copy(.45f), CircleShape), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) { drawCircle(Brush.radialGradient(listOf(Color.White.copy(.55f), Color.Transparent), center = Offset(size.width * .3f, size.height * .2f), radius = size.minDimension * .75f)); drawCircle(Color.White.copy(.12f), style = Stroke(1.dp.toPx()), radius = size.minDimension * .42f) }
        Text(glyph, color = White, fontSize = 35.sp, fontWeight = FontWeight.Light)
    }
}

@Composable private fun WallpaperPage(activity: ComponentActivity, preset: ThemePreset, imported: Bitmap?, selectedColor: Int, blur: Float, glass: Float,
    choose: (Int) -> Unit, setBlur: (Float) -> Unit, setGlass: (Float) -> Unit, pick: () -> Unit, message: (String) -> Unit, saved: () -> Unit) = Screen {
    Spacer(Modifier.height(8.dp)); Title("Kreator tapet", "Projekt zapisujesz lokalnie. Eksport PNG działa offline; ustawienie korzysta z WallpaperManager Androida.")
    WallpaperPreview(preset, imported, selectedColor, glass, blur, Modifier.fillMaxWidth().height(340.dp))
        Row(Modifier.fillMaxWidth().padding(top = 11.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        ActionButton("Importuj zdjęcie", pick, Icons.Rounded.AddPhotoAlternate, Modifier.weight(1f))
        ActionButton("Zapisz projekt", { saveProject(activity, "Tapeta • ${preset.name}", renderWallpaper(preset, imported, selectedColor, glass, blur)); saved(); message("Projekt i podgląd PNG zapisane lokalnie") }, Icons.Rounded.Save, Modifier.weight(1f), outlined = true)
    }
    GlassCard(Modifier.padding(top = 13.dp, bottom = 13.dp)) {
        SectionLabel("KOLORY MOTYWU")
        Row(horizontalArrangement = Arrangement.spacedBy(11.dp)) { preset.colors.forEachIndexed { index, color -> ColorDot(color, selectedColor == index) { choose(index) } }; AccentSet.forEachIndexed { i, v -> ColorDot(Color(v), selectedColor == i + 3) { choose(i + 3) } } }
        Spacer(Modifier.height(13.dp)); Text("Szkło i refleks", color = White, fontSize = 12.sp); Slider(value = glass, onValueChange = setGlass, colors = SliderDefaults.colors(thumbColor = Ice, activeTrackColor = Ice))
        Text("Miękkie światło", color = White, fontSize = 12.sp); Slider(value = blur, onValueChange = setBlur, colors = SliderDefaults.colors(thumbColor = Ice, activeTrackColor = Ice))
        Text("Suwak steruje siłą poświaty na podglądzie. Zdjęcie źródłowe pozostaje bez zmian.", color = Muted, fontSize = 10.sp)
    }
    SectionLabel("ZASTOSUJ LUB WYEKSPORTUJ")
    ActionButton("Ustaw na ekranie głównym", { runCatching { activity.getSystemService(WallpaperManager::class.java).setBitmap(renderWallpaper(preset, imported, selectedColor, glass, blur), null, true, WallpaperManager.FLAG_SYSTEM); message("Tapeta ekranu głównego została ustawiona") }.onFailure { message("Nie udało się ustawić tapety: ${it.localizedMessage ?: "sprawdź ustawienia urządzenia"}") } }, Icons.Rounded.Home, Modifier.fillMaxWidth())
    ActionButton("Ustaw na ekranie blokady", { runCatching { activity.getSystemService(WallpaperManager::class.java).setBitmap(renderWallpaper(preset, imported, selectedColor, glass, blur), null, true, WallpaperManager.FLAG_LOCK); message("Tapeta ekranu blokady została ustawiona") }.onFailure { message("To urządzenie nie pozwoliło ustawić tapety blokady") } }, Icons.Rounded.Lock, Modifier.fillMaxWidth().padding(top = 9.dp), outlined = true)
    ActionButton("Ustaw na obu ekranach", { runCatching { activity.getSystemService(WallpaperManager::class.java).setBitmap(renderWallpaper(preset, imported, selectedColor, glass, blur), null, true, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK); message("Tapeta została ustawiona") }.onFailure { message("Urządzenie nie obsłużyło ustawienia obu tapet") } }, Icons.Rounded.Layers, Modifier.fillMaxWidth().padding(top = 9.dp), outlined = true)
    ActionButton("Eksportuj tapetę PNG", { runCatching { exportPng(activity, renderWallpaper(preset, imported, selectedColor, glass, blur), "GlassCustomizer-${preset.name.replace(' ', '-')}"); message("PNG zapisany w Zdjęciach") }.onFailure { message("Eksport się nie powiódł") } }, Icons.Rounded.FileDownload, Modifier.fillMaxWidth().padding(top = 9.dp))
    Text("Ustawianie tapety przekazuje grafikę do oficjalnego WallpaperManager. Ekran blokady może być ograniczony przez One UI.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(vertical = 12.dp))
}

@Composable private fun WallpaperPreview(preset: ThemePreset, imported: Bitmap?, selected: Int, glass: Float, glow: Float, modifier: Modifier = Modifier) {
    val colors = remember(preset, selected) {
        val chosen = if (selected < preset.colors.size) preset.colors[selected] else Color(AccentSet[(selected - 3).coerceIn(0, AccentSet.lastIndex)])
        listOf(chosen, preset.colors[1], preset.colors[2])
    }
    Box(modifier.clip(RoundedCornerShape(29.dp)).background(Brush.linearGradient(colors)).border(1.dp, Color.White.copy(.3f), RoundedCornerShape(29.dp))) {
        Canvas(Modifier.fillMaxSize()) {
            val native = drawContext.canvas.nativeCanvas
            imported?.let { bitmap -> val dst = RectF(0f, 0f, size.width, size.height); val scale = maxOf(size.width / bitmap.width, size.height / bitmap.height); val w = bitmap.width * scale; val h = bitmap.height * scale; dst.set((size.width-w)/2, (size.height-h)/2, (size.width+w)/2, (size.height+h)/2); val p = Paint(3).apply { alpha = 220 }; native.drawBitmap(bitmap, null, dst, p) }
            drawCircle(Brush.radialGradient(listOf(Color.White.copy(.08f + glow*.5f), Color.Transparent), center = Offset(size.width*.76f,size.height*.18f), radius=size.width*.8f), radius=size.width*.8f, center=Offset(size.width*.76f,size.height*.18f))
            drawCircle(colors[0].copy(alpha = .28f), radius=size.width*.34f, center=Offset(size.width*.86f,size.height*.56f))
            val glassPaint = Paint(3).apply { color = android.graphics.Color.argb((glass*100).toInt().coerceIn(0,100),255,255,255); style=Paint.Style.FILL }
            native.drawRoundRect(RectF(size.width*.09f,size.height*.72f,size.width*.91f,size.height*.88f),28f,28f,glassPaint)
            val edge = Paint(3).apply { color = android.graphics.Color.argb(105,255,255,255); style=Paint.Style.STROKE; strokeWidth=1.2f }
            native.drawRoundRect(RectF(size.width*.09f,size.height*.72f,size.width*.91f,size.height*.88f),28f,28f,edge)
        }
        Column(Modifier.align(Alignment.TopCenter).padding(top = 37.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), color = White, fontSize = 54.sp, fontWeight = FontWeight.ExtraLight)
            Text(SimpleDateFormat("EEEE, d MMMM", Locale("pl")).format(Date()).uppercase(), color = White.copy(.83f), fontSize = 10.sp, letterSpacing = 1.8.sp)
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom=31.dp), horizontalArrangement=Arrangement.spacedBy(12.dp)) { repeat(4) { Box(Modifier.size(31.dp).clip(CircleShape).background(Color.White.copy(.22f)).border(1.dp,Color.White.copy(.3f),CircleShape)) } }
        Box(Modifier.align(Alignment.TopEnd).padding(14.dp).clip(CircleShape).background(Color.Black.copy(.28f)).padding(horizontal=9.dp,vertical=5.dp)) { Text("PODGLĄD",fontSize=8.sp,color=White,letterSpacing=1.sp) }
    }
}

@Composable private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) { val scale by animateFloatAsState(if (selected) 1.16f else 1f, label="dot"); Box(Modifier.size(30.dp).clickable { onClick() }, contentAlignment=Alignment.Center) { Box(Modifier.size((22*scale).dp).clip(CircleShape).background(color).border(if(selected) 2.dp else 1.dp, if(selected) White else White.copy(.25f), CircleShape)) } }

@Composable private fun StudioPage(activity: ComponentActivity, preset: ThemePreset, design: String, select: (String) -> Unit, pick: () -> Unit, message: (String) -> Unit) = Screen {
    Spacer(Modifier.height(8.dp)); Title("Glass studio", "Projektuj grafikę do eksportu. Zastosowanie elementów systemu zależy od obsługi narzędzia Samsunga lub launchera.")
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf("Szkło", "Ikona", "Quick Panel", "Lock screen", "Klawiatura").forEach { name -> FilterChip(selected = design == name, onClick = { select(name) }, label = { Text(name, fontSize = 11.sp) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0x4434CFFF), selectedLabelColor = Ice)) } }
    GlassCard(Modifier.padding(top = 14.dp, bottom = 13.dp)) {
        SectionLabel("PODGLĄD • $design".uppercase())
        Box(Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(preset.colors))) {
            Canvas(Modifier.fillMaxSize()) { drawCircle(Brush.radialGradient(listOf(Color.White.copy(.55f), Color.Transparent), center=Offset(size.width*.35f,size.height*.25f),radius=size.width*.6f), radius=size.width*.6f, center=Offset(size.width*.35f,size.height*.25f)); repeat(5) { i -> drawRoundRect(Color.White.copy(.10f+i*.025f), topLeft=Offset(size.width*.12f,size.height*(.18f+i*.13f)), size=androidx.compose.ui.geometry.Size(size.width*.76f,if(design=="Ikona") size.height*.12f else size.height*.09f), cornerRadius=androidx.compose.ui.geometry.CornerRadius(25f)) }; drawCircle(Color.White.copy(.32f), radius=size.minDimension*.22f, center=Offset(size.width*.5f,size.height*.52f), style=Stroke(2.dp.toPx())) }
            Text(when(design){"Ikona"->"✦";"Quick Panel"->"◉";"Klawiatura"->"⌨";else->"◈"}, Modifier.align(Alignment.Center), color=White, fontSize=57.sp, fontWeight=FontWeight.Light)
            Text("${preset.name.uppercase()}  /  GLASS", Modifier.align(Alignment.BottomCenter).padding(bottom=17.dp), color=White.copy(.84f), fontSize=9.sp, letterSpacing=1.4.sp)
        }
        if (design == "Ikona") { ActionButton("Importuj obraz jako ikonę", pick, Icons.Rounded.AddPhotoAlternate, Modifier.fillMaxWidth().padding(top=12.dp), outlined=true) }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.padding(top=13.dp)) { ColorDot(Ice,true) {}; ColorDot(Color(0xFFBFA6FF),false) {}; ColorDot(Color(0xFFFF718D),false) {}; ColorDot(Color(0xFFBFC8D8),false) {}; Text("Paleta motywu", color=Muted, fontSize=10.sp, modifier=Modifier.align(Alignment.CenterVertically)) }
    }
    ActionButton("Eksportuj grafikę PNG", { runCatching { exportPng(activity, renderStudioAsset(preset, design), "Glass-${design.replace(' ','-')}"); message("Grafika PNG zapisana w Zdjęciach") }.onFailure { message("Nie udało się wyeksportować PNG") } }, Icons.Rounded.FileDownload, Modifier.fillMaxWidth())
    if (design == "Quick Panel" || design == "Klawiatura" || design == "Lock screen") {
        GlassCard(Modifier.padding(top=12.dp,bottom=15.dp)) { Icon(Icons.Rounded.Info,null,tint=Ice); Text(when(design){"Quick Panel"->"Projekt jest grafiką do wykorzystania w obsługiwanych narzędziach. Publiczne API Androida nie pozwala tej aplikacji bezpośrednio podmienić systemowego Quick Panelu.";"Klawiatura"->"Eksportuj tło, a następnie ustaw je ręcznie w obsługiwanej klawiaturze. Aplikacja nie zmienia ani nie wybiera klawiatury za Ciebie.";else->"To dekoracyjny podgląd. Zegar i powiadomienia systemowe konfiguruje One UI; PNG eksportuje samo tło."}, Modifier.padding(top=8.dp), color=White, fontSize=12.sp, lineHeight=18.sp) }
    }
    if (design == "Ikona") Text("Eksport PNG nie zmieni sam ikon One UI. Kompatybilny launcher lub Theme Park może wymagać własnego pakietu i ręcznego mapowania.", color=Muted, fontSize=11.sp, lineHeight=16.sp, modifier=Modifier.padding(vertical=12.dp))
}

@Composable private fun SamsungPage(activity: ComponentActivity) = Screen {
    Spacer(Modifier.height(8.dp)); Title("Samsung hub", "Co GLASS CUSTOMIZER potrafi zrobić, a gdzie decyzję podejmuje One UI.")
    GlassCard(Modifier.padding(bottom=12.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Rounded.VerifiedUser,null,tint=Color(0xFF8DE3C2)); Text("Bez roota • bez ukrytych API • ustawienia zmieniasz Ty", Modifier.padding(start=10.dp), color=White, fontSize=12.sp, fontWeight=FontWeight.SemiBold) } }
    val rows = listOf(
        Triple("Tapety", "Aplikacja może bezpośrednio ustawić wygenerowaną grafikę przez WallpaperManager.", "Dostępne bezpośrednio"),
        Triple("Ikony", "PNG wyeksportujesz tutaj. One UI: ręczne ustawienie lub Theme Park; paczka ikon zależy od launchera.", "Theme Park / launcher"),
        Triple("Quick Panel", "Projekt graficzny i eksport. Bezpośrednia zmiana przez publiczne API jest niedostępna.", "Theme Park / niedostępne API"),
        Triple("Ekran blokady", "Możesz ustawić tapetę. Zegar i układ powiadomień dostosowuje One UI.", "Ustawienia One UI"),
        Triple("Klawiatura", "Eksport tła; zastosuj ręcznie w obsługiwanej klawiaturze. Brak cichej zmiany klawiatury.", "Ręczna konfiguracja"),
        Triple("Widgety", "Widget zegara dodajesz z listy widgetów ekranu głównego.", "Dodajesz samodzielnie"),
        Triple("Kolory systemowe", "Paleta podglądu i tapety. Kolory motywu systemowego może zmienić One UI.", "Ustawienia / Theme Park")
    )
    rows.forEach { (name, detail, state) -> GlassCard(Modifier.padding(bottom=9.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Text(name, Modifier.weight(1f), color=White, fontWeight=FontWeight.Bold); Text(state, color=Ice, fontSize=9.sp) }; Text(detail, color=Muted, fontSize=11.sp, lineHeight=16.sp, modifier=Modifier.padding(top=8.dp)) } }
    SectionLabel("BEZPIECZNE SKRÓTY")
    ActionButton("Otwórz systemowy wybór tapety", { runCatching { activity.startActivity(android.content.Intent(android.content.Intent.ACTION_SET_WALLPAPER)) } }, Icons.Rounded.Settings, Modifier.fillMaxWidth())
    ActionButton("Informacje o aplikacji", { runCatching { activity.startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${activity.packageName}"))) } }, Icons.Rounded.AppSettingsAlt, Modifier.fillMaxWidth().padding(top=9.dp), outlined=true)
    Text("Good Lock i Theme Park są narzędziami Samsunga. Ich dostępność zależy od regionu, modelu i wersji One UI.", color=Muted, fontSize=10.sp, lineHeight=15.sp, modifier=Modifier.padding(vertical=14.dp))
}

@Composable private fun PresetsPage(active: ThemePreset, apply: (ThemePreset) -> Unit) = Screen {
    Spacer(Modifier.height(8.dp)); Title("Gotowe motywy", "10 palet Liquid Glass z dopasowanymi kolorami i dekoracjami. Podgląd nie podmienia samoczynnie ikon ani ustawień One UI.")
    presets.forEach { item ->
        GlassCard(Modifier.padding(bottom=10.dp).clickable { apply(item) }) {
            Row(verticalAlignment=Alignment.CenterVertically) { ThemeOrb(item.colors,item.glyph,Modifier.size(61.dp)); Column(Modifier.weight(1f).padding(horizontal=13.dp)) { Text(item.name,color=White,fontWeight=FontWeight.Bold,fontSize=15.sp); Text(item.tag,color=Muted,fontSize=9.sp,letterSpacing=1.sp,modifier=Modifier.padding(top=3.dp)) }; if (item == active) Icon(Icons.Rounded.CheckCircle,null,tint=Ice) else Icon(Icons.Rounded.ChevronRight,null,tint=Muted) }
            Row(Modifier.fillMaxWidth().padding(start=74.dp,top=11.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) { item.colors.forEach { Box(Modifier.weight(1f).height(4.dp).clip(CircleShape).background(it)) } }
        }
    }
}

@Composable private fun ProjectsPage(activity: ComponentActivity, refresh: Int, message: (String) -> Unit) {
    val prefs = remember(activity, refresh) { activity.getSharedPreferences("glass_projects", 0) }
    var names by remember(refresh) { mutableStateOf(prefs.getStringSet("names", emptySet())?.toList()?.sorted() ?: emptyList()) }
    Screen {
        Spacer(Modifier.height(8.dp)); Title("Twoje projekty", "Projekty są przechowywane lokalnie w aplikacji. Zapisuj je z edytora tapet.")
        if (names.isEmpty()) GlassCard(Modifier.padding(bottom=12.dp)) { Icon(Icons.Rounded.FolderOpen,null,tint=Ice); Text("Na razie jest tu pusto.",color=White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=9.dp)); Text("Otwórz Kreator tapet i wybierz „Zapisz projekt”.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=4.dp)) }
        names.forEachIndexed { index, name -> GlassCard(Modifier.padding(bottom=9.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Rounded.Image,null,tint=Ice); Text(name,Modifier.weight(1f).padding(horizontal=9.dp),color=White,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis); IconButton(onClick={ duplicateProject(activity,name); names=loadProjectNames(activity); message("Zduplikowano projekt") }) { Icon(Icons.Rounded.ContentCopy,null,tint=Muted) }; IconButton(onClick={ deleteProject(activity,name); names=loadProjectNames(activity); message("Projekt usunięty") }) { Icon(Icons.Rounded.DeleteOutline,null,tint=Color(0xFFFF8792)) } } } }
        GlassCard(Modifier.padding(top=7.dp)) { Icon(Icons.Rounded.Info,null,tint=Ice); Text("Projekty przechowują lokalny render PNG. Edycja warstw po zapisaniu nie jest jeszcze dostępna.", color=Muted,fontSize=11.sp,lineHeight=16.sp,modifier=Modifier.padding(top=7.dp)) }
    }
}

@Composable private fun ActionButton(label: String, onClick: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, outlined: Boolean = false) {
    Button(onClick=onClick, modifier=modifier.heightIn(min=48.dp), shape=RoundedCornerShape(16.dp), colors=ButtonDefaults.buttonColors(containerColor=if(outlined) Color(0x3346CFFF) else Color(0xFF86DEFA), contentColor=if(outlined) Ice else Color(0xFF07101B)), border=if(outlined) androidx.compose.foundation.BorderStroke(1.dp,Ice.copy(.28f)) else null, contentPadding=PaddingValues(horizontal=12.dp,vertical=9.dp)) {
        Icon(icon,null,modifier=Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text(label,fontSize=11.sp,fontWeight=FontWeight.Bold,lineHeight=14.sp)
    }
}

private fun projectDir(activity: ComponentActivity) = java.io.File(activity.filesDir,"projects").apply { mkdirs() }
private fun projectFile(activity: ComponentActivity,name:String) = java.io.File(projectDir(activity), java.util.UUID.nameUUIDFromBytes(name.toByteArray()).toString()+".png")
private fun loadProjectNames(activity: ComponentActivity): List<String> = activity.getSharedPreferences("glass_projects",0).getStringSet("names",emptySet())?.toList()?.sorted() ?: emptyList()
private fun saveProject(activity: ComponentActivity, name: String, bitmap:Bitmap) {
    val prefs=activity.getSharedPreferences("glass_projects",0); val names=prefs.getStringSet("names",emptySet())?.toMutableSet() ?: mutableSetOf(); names.add(name); projectFile(activity,name).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) }; prefs.edit().putStringSet("names",names).apply()
}
private fun decodePhoto(activity:ComponentActivity,uri:Uri):Bitmap {
    val resolver=activity.contentResolver
    val bounds=android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds=true }
    resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it,null,bounds) } ?: error("Nie można odczytać zdjęcia")
    var sample=1
    while (bounds.outWidth/sample>1800 || bounds.outHeight/sample>2400) sample*=2
    val options=android.graphics.BitmapFactory.Options().apply { inSampleSize=sample.coerceAtLeast(1); inPreferredConfig=Bitmap.Config.ARGB_8888 }
    return resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it,null,options) } ?: error("Nie można otworzyć zdjęcia")
}
private fun duplicateProject(activity:ComponentActivity,name:String) {
    val copy="$name (kopia)"; projectFile(activity,name).takeIf{it.exists()}?.copyTo(projectFile(activity,copy),overwrite=true)
    val prefs=activity.getSharedPreferences("glass_projects",0); val names=prefs.getStringSet("names",emptySet())?.toMutableSet() ?: mutableSetOf(); names.add(copy); prefs.edit().putStringSet("names",names).apply()
}
private fun deleteProject(activity:ComponentActivity,name:String) {
    projectFile(activity,name).delete(); val prefs=activity.getSharedPreferences("glass_projects",0); val names=prefs.getStringSet("names",emptySet())?.toMutableSet() ?: mutableSetOf(); names.remove(name); prefs.edit().putStringSet("names",names).apply()
}

private fun renderWallpaper(preset: ThemePreset, imported: Bitmap?, selected: Int, glass: Float, glow:Float = .12f): Bitmap {
    val bitmap=Bitmap.createBitmap(1080,2400,Bitmap.Config.ARGB_8888); val c=NativeCanvas(bitmap)
    val accent=if(selected<preset.colors.size) preset.colors[selected] else Color(AccentSet[(selected-3).coerceIn(0,AccentSet.lastIndex)])
    val colors=intArrayOf(accent.toArgb(),preset.colors[1].toArgb(),preset.colors[2].toArgb())
    val p=Paint(3).apply { shader=LinearGradient(0f,0f,1080f,2400f,colors,null,Shader.TileMode.CLAMP) }; c.drawRect(0f,0f,1080f,2400f,p); p.shader=null
    imported?.let { image -> val scale=maxOf(1080f/image.width,2400f/image.height); val w=image.width*scale; val h=image.height*scale; p.alpha=225; c.drawBitmap(image,null,RectF((1080-w)/2,(2400-h)/2,(1080+w)/2,(2400+h)/2),p); p.alpha=255 }
    p.shader=android.graphics.RadialGradient(830f,420f,1000f,intArrayOf(android.graphics.Color.argb((35+glow*130).toInt().coerceIn(35,165),255,255,255),android.graphics.Color.TRANSPARENT),null,Shader.TileMode.CLAMP); c.drawCircle(830f,420f,1000f,p); p.shader=null
    p.color=android.graphics.Color.argb((glass*115).toInt().coerceIn(0,115),255,255,255); c.drawRoundRect(RectF(110f,1770f,970f,2055f),90f,90f,p)
    p.color=android.graphics.Color.argb(90,255,255,255); p.style=Paint.Style.STROKE;p.strokeWidth=4f;c.drawRoundRect(RectF(110f,1770f,970f,2055f),90f,90f,p);p.style=Paint.Style.FILL
    for(i in 0..3){p.color=android.graphics.Color.argb(70,255,255,255);c.drawCircle(400f+i*100,2200f,28f,p)}
    return bitmap
}

private fun renderStudioAsset(preset: ThemePreset, design: String): Bitmap {
    val side = 1024
    val bitmap = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
    val canvas = NativeCanvas(bitmap)
    val paint = Paint(3).apply { shader = LinearGradient(0f, 0f, side.toFloat(), side.toFloat(), intArrayOf(preset.colors[0].toArgb(), preset.colors[1].toArgb(), preset.colors[2].toArgb()), null, Shader.TileMode.CLAMP) }
    when (design) {
        "Ikona" -> {
            canvas.drawCircle(512f, 512f, 490f, paint)
            paint.shader = null; paint.color = android.graphics.Color.argb(100, 255, 255, 255); canvas.drawCircle(350f, 300f, 270f, paint)
            paint.color = android.graphics.Color.argb(155, 255, 255, 255); paint.style = Paint.Style.STROKE; paint.strokeWidth = 15f; canvas.drawCircle(512f, 512f, 445f, paint)
            paint.style = Paint.Style.FILL; paint.color = android.graphics.Color.WHITE; paint.textAlign = Paint.Align.CENTER; paint.textSize = 400f; paint.typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL); canvas.drawText("✦", 512f, 650f, paint)
        }
        "Szkło" -> {
            canvas.drawRect(0f, 0f, side.toFloat(), side.toFloat(), paint); paint.shader = null; paint.color = android.graphics.Color.argb(100, 255, 255, 255); canvas.drawRoundRect(RectF(100f, 330f, 924f, 690f), 90f, 90f, paint)
            paint.color = android.graphics.Color.argb(150, 255, 255, 255); paint.style = Paint.Style.STROKE; paint.strokeWidth = 7f; canvas.drawRoundRect(RectF(100f, 330f, 924f, 690f), 90f, 90f, paint)
        }
        else -> {
            canvas.drawRect(0f, 0f, side.toFloat(), side.toFloat(), paint); paint.shader = null; paint.color = android.graphics.Color.argb(95, 255, 255, 255)
            for (i in 0..4) canvas.drawRoundRect(RectF(90f, 130f + i * 155, 934f, 260f + i * 155), 45f, 45f, paint)
            paint.color = android.graphics.Color.argb(160, 255, 255, 255); paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f; canvas.drawRoundRect(RectF(90f, 130f, 934f, 905f), 65f, 65f, paint)
        }
    }
    return bitmap
}

private fun exportPng(activity: ComponentActivity, bitmap: Bitmap, name: String) {
    val values=ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME,"$name.png"); put(MediaStore.Images.Media.MIME_TYPE,"image/png"); if(Build.VERSION.SDK_INT>=29) put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/GlassCustomizer") }
    val uri=activity.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values) ?: error("Brak miejsca na zapis")
    activity.contentResolver.openOutputStream(uri)?.use { if(!bitmap.compress(Bitmap.CompressFormat.PNG,100,it)) error("Zapis PNG nie powiódł się") } ?: error("Nie można otworzyć pliku")
}

private fun Color.toArgb(): Int = android.graphics.Color.argb((alpha*255).toInt(),(red*255).toInt(),(green*255).toInt(),(blue*255).toInt())
